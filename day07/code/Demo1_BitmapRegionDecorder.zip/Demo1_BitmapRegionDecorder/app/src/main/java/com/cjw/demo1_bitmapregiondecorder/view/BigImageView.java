package com.cjw.demo1_bitmapregiondecorder.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapRegionDecoder;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Scroller;

import java.io.IOException;
import java.io.InputStream;

/**
 * 长图加载控件
 * Created by chenjiawei on 2018/1/29.
 */

public class BigImageView extends View implements View.OnTouchListener {

    private BitmapFactory.Options mOptions;

    /**
     * 大图加载设定的矩形
     */
    private Rect mRect;

    /**
     * 大图加载
     */
    private BitmapRegionDecoder mDecoder;

    /**
     * 图片宽度
     */
    private int mImageWidth;

    /**
     * 图片高度
     */
    private int mImageHeight;

    /**
     * 缓存图片
     */
    private Bitmap mCacheBitmap;

    private Matrix mBitmapDrawMatrix;

    /**
     * 手势处理
     */
    private GestureDetector mGestureDetector;

    /**
     * 滑动帮助类
     */
    private Scroller mScroller;

    /**
     * 控件宽度
     */
    private int mViewWidth;

    /**
     * 控件高度
     */
    private int mViewHeight;

    /**
     * 缩放倍数
     */
    private float mScale;

    public BigImageView(Context context) {
        this(context, null);
    }

    public BigImageView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public BigImageView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        mOptions = new BitmapFactory.Options();
        mRect = new Rect();
        mBitmapDrawMatrix = new Matrix();

        GestureDetector.OnGestureListener listener = new OnGestureListener();
        mGestureDetector = new GestureDetector(context, listener);

        mScroller = new Scroller(context);

        setOnTouchListener(this);
    }

    /**
     * 加载图片
     *
     * @param bitmapInputStream 图片输入流
     */
    public void loadBitmap(InputStream bitmapInputStream) {
        // 获取原图的宽高
        mOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(bitmapInputStream, null, mOptions);

        mImageWidth = mOptions.outWidth;
        mImageHeight = mOptions.outHeight;

        mOptions.inJustDecodeBounds = false;
        mOptions.inMutable = true;
        mOptions.inPreferredConfig = Bitmap.Config.RGB_565;
        try {
            mDecoder = BitmapRegionDecoder.newInstance(bitmapInputStream, false);
        } catch (IOException e) {
            e.printStackTrace();
        }
        requestLayout();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mDecoder == null) {
            return;
        }

        mViewWidth = getWidth();
        mViewHeight = getHeight();

        mScale = 1.0f * mImageWidth / mViewWidth;

        mRect.left = 0;
        mRect.right = mImageWidth;
        mRect.bottom = mRect.top + (int) (mViewHeight * mScale);

        // 缓存图片
        mOptions.inBitmap = mCacheBitmap;
        // 加载Bitmap
        mCacheBitmap = mDecoder.decodeRegion(mRect, mOptions);

        // 绘制Bitmap
        mBitmapDrawMatrix.reset();
        mBitmapDrawMatrix.setScale(1 / mScale, 1 / mScale);
        canvas.drawBitmap(mCacheBitmap, mBitmapDrawMatrix, null);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        // 触摸事件交给手势处理器来进行处理
        return mGestureDetector.onTouchEvent(event);
    }

    /**
     * 手势监听
     */
    private class OnGestureListener implements GestureDetector.OnGestureListener {

        @Override
        public boolean onDown(MotionEvent e) {
            if (!mScroller.isFinished()) {
                // 如果在惯性滑动的过程中触摸了屏幕,停止惯性滑动
                mScroller.forceFinished(true);
            }
            // 返回 true 代表处理按下之后的事件(例如:抬起,滑动)
            return true;
        }

        @Override
        public void onShowPress(MotionEvent e) {

        }

        @Override
        public boolean onSingleTapUp(MotionEvent e) {
            return false;
        }

        /**
         * 滚动
         *
         * @param e1        起始点
         * @param e2        当前点
         * @param distanceX 水平移动距离
         * @param distanceY 垂直移动距离
         * @return
         */
        @Override
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            mRect.top += distanceY;
            mRect.bottom += distanceY;

            if (mRect.top < 0) {
                mRect.top = 0;
                mRect.bottom = (int) (mViewHeight * mScale);
            }

            if (mRect.bottom > mImageHeight) {
                mRect.bottom = mImageHeight;
                mRect.top = (int) (mRect.bottom - mViewHeight * mScale);
            }

            // 刷新
            invalidate();
            return false;
        }

        @Override
        public void onLongPress(MotionEvent e) {

        }

        /**
         * 惯性滑动
         *
         * @param e1        起始点
         * @param e2        当前点
         * @param velocityX 水平速度
         * @param velocityY 垂直速度
         * @return
         */
        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            // 利用 Scroller 辅助类计算距离
            mScroller.fling(0, mRect.top,
                    (int) velocityX, (int) -velocityY, 0, 0,
                    0, (int) (mImageHeight - mViewHeight * mScale));
            return false;
        }
    }

    /**
     * 获取滑动的计算结果
     */
    @Override
    public void computeScroll() {
        if (mScroller.isFinished()) {
            // 已经停止滑动,不进行计算
            return;
        }

        if (mScroller.computeScrollOffset()) {
            // 动画没有结束
            mRect.top = mScroller.getCurrY();
            mRect.bottom = (int) (mRect.top + mViewHeight * mScale);
            invalidate();
        }
    }
}
