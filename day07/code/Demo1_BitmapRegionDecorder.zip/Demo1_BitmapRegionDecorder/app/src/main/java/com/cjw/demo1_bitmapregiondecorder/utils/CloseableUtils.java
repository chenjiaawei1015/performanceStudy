package com.cjw.demo1_bitmapregiondecorder.utils;

import android.support.annotation.NonNull;

import java.io.Closeable;
import java.io.IOException;

/**
 * Created by chenjiawei on 2018/1/27.
 */

public class CloseableUtils {

    public static void close(Closeable closeable) {
        try {
            if (closeable != null) {
                closeable.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
