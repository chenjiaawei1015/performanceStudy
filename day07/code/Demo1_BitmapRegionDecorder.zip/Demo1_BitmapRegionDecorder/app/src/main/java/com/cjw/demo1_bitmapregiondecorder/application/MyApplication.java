package com.cjw.demo1_bitmapregiondecorder.application;

import android.app.Application;

import com.blankj.utilcode.util.Utils;

/**
 * Created by chenjiawei on 2018/1/30.
 */

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Utils.init(this);
    }
}
