package com.cjw.demo1_bitmapregiondecorder;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapRegionDecoder;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

import com.blankj.utilcode.util.LogUtils;
import com.cjw.demo1_bitmapregiondecorder.utils.CloseableUtils;
import com.cjw.demo1_bitmapregiondecorder.view.BigImageView;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    private static final String FILE_NAME = "big.png";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        testBigImageView();

//        testBitmapRegionDecoder();
    }

    /**
     * BigImageView 测试
     */
    private void testBigImageView() {
        setContentView(R.layout.activity_main);
        BigImageView picIv = findViewById(R.id.pic_iv);

        InputStream in = null;
        try {
            in = getAssets().open(FILE_NAME);
            picIv.loadBitmap(in);
        } catch (Exception e) {
            LogUtils.e(e);
        } finally {
            CloseableUtils.close(in);
        }
    }

    /**
     * BitmapRegionDecoder 测试
     */
    private void testBitmapRegionDecoder() {
        setContentView(R.layout.activity_test);
        ImageView picIv = findViewById(R.id.test_iv);

        InputStream in = null;
        try {
            in = getAssets().open(FILE_NAME);
            BitmapRegionDecoder decoder = BitmapRegionDecoder.newInstance(in, false);

            // 取左上角 100 * 100 的图片区域
            int left = 0;
            int top = 0;
            int right = 100;
            int bottom = 100;
            Rect rect = new Rect(left, top, right, bottom);

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inMutable = true;
            Bitmap bitmap = decoder.decodeRegion(rect, options);
            picIv.setImageBitmap(bitmap);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            CloseableUtils.close(in);
        }
    }
}
